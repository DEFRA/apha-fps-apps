﻿# Apha.BatchJobs.Console - Project Overview

## Application Details
- **Account Name**: DEFRA-APHA
- **Project Name**: Apha FPS Apps - BatchJobs
- **Application Name**: Apha.BatchJobs.Console
- **Type**: Console Application / Batch Processing
- **Target Framework**: .NET 10 (net10.0)

## Purpose
Cross-cutting batch processing console application for Apha FPS solution. Handles scheduled and adhoc jobs across multiple domains (FPS, PACT, PIMS, Costbook).

## Key Jobs
1. **Scheduled Jobs**: Year-end transfers, recurring operations
2. **Adhoc Jobs**: Summary generation, one-off processing tasks

## Architecture
- **Domain**: Apha.BatchJobs (separate cross-cutting domain)
- **Pattern**: Clean Architecture with layered design
- **Dependencies**: References Apha.FPS.Application, Apha.PACT.Application, Apha.PIMS.Application, Apha.Costbook.Application, Apha.Common

## Documentation
See ARCHITECTURE_GUIDE.md for comprehensive patterns, best practices, and implementation details.
