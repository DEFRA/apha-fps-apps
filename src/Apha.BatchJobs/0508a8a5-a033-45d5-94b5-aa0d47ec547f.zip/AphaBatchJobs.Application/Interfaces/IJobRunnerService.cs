namespace AphaBatchJobs.Application.Interfaces;

/// <summary>
/// Service interface for running batch jobs in scheduled or adhoc mode.
/// </summary>
public interface IJobRunnerService
{
    /// <summary>
    /// Runs all registered scheduled jobs sequentially.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token to stop execution.</param>
    /// <returns>Exit code indicating overall execution status.</returns>
    Task<int> RunScheduledAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Runs a specific adhoc job by name.
    /// </summary>
    /// <param name="jobName">The name of the adhoc job to execute.</param>
    /// <param name="cancellationToken">Cancellation token to stop execution.</param>
    /// <returns>Exit code indicating job execution status.</returns>
    Task<int> RunAdhocAsync(string jobName, CancellationToken cancellationToken = default);
}

// Review Comments:
// 1. Added default parameter values for CancellationToken (= default) to follow .NET 8 best practices
//    This makes the API more flexible and allows callers to omit the parameter when not needed
// 2. The interface is clean and follows SOLID principles with clear separation of concerns
// 3. XML documentation is comprehensive and follows standard conventions
// 4. Method naming follows async suffix convention properly
// 5. Return type of int for exit codes is appropriate for batch job scenarios
// 6. Consider adding nullable annotation for jobName parameter if null values should be handled:
//    Task<int> RunAdhocAsync(string? jobName, CancellationToken cancellationToken = default);
//    However, this depends on whether null job names are valid in your domain logic