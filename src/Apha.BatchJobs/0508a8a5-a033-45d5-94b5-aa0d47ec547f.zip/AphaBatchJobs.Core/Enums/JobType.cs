namespace AphaBatchJobs.Core.Enums;

/// <summary>
/// Defines the type of job trigger mechanism.
/// Used to distinguish between scheduled jobs that run on a cron schedule
/// and adhoc jobs that run on demand.
/// </summary>
public enum JobType
{
    /// <summary>
    /// Represents a job that runs on a predefined schedule (cron-based).
    /// </summary>
    Scheduled = 0,

    /// <summary>
    /// Represents a job that runs on demand with explicit invocation.
    /// </summary>
    Adhoc = 1
}


// Review Comments:
// ================
// The code is well-structured and follows .NET 8 best practices. No changes are required because:
//
// 1. ✓ Namespace follows proper naming conventions (PascalCase)
// 2. ✓ Enum uses PascalCase naming convention
// 3. ✓ XML documentation is comprehensive and clear
// 4. ✓ Explicit integer values are assigned (good for database persistence)
// 5. ✓ Default value starts at 0 (follows .NET conventions)
// 6. ✓ File-scoped namespace is NOT used here, but for a simple enum file, 
//       either style is acceptable in .NET 8
// 7. ✓ Enum members are clearly named and self-documenting
//
// Optional Enhancement (not implemented as per instructions):
// - Could add [JsonConverter] attributes if JSON serialization behavior needs customization
// - Could add [Description] attributes for display purposes
// - Could consider file-scoped namespace (namespace AphaBatchJobs.Core.Enums;) 
//   but current style is perfectly valid