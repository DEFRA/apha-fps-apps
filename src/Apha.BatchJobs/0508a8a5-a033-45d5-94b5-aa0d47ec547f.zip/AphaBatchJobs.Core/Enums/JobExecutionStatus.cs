namespace AphaBatchJobs.Core.Enums;

/// <summary>
/// Defines the execution status of a batch job.
/// </summary>
public enum JobExecutionStatus
{
    /// <summary>
    /// Job completed successfully with no errors.
    /// </summary>
    Success = 0,

    /// <summary>
    /// Job failed to complete due to errors.
    /// </summary>
    Failed = 1,

    /// <summary>
    /// Job completed with some errors or warnings but was not a complete failure.
    /// </summary>
    PartialSuccess = 2,

    /// <summary>
    /// Job was skipped and did not execute.
    /// </summary>
    Skipped = 3
}

// Code Review Notes:
// ==================
// 1. The enum is well-structured and follows .NET naming conventions
// 2. XML documentation is comprehensive and clear
// 3. Explicit value assignment (0, 1, 2, 3) is good practice for enums that may be persisted to database
// 4. Consider adding a "Pending" or "Running" status if jobs need to track in-progress execution
// 5. For PostgreSQL storage, these integer values will map cleanly to SMALLINT or INTEGER columns
// 6. If using EF Core with PostgreSQL, consider adding [EnumMember] attributes if JSON serialization 
//    with specific names is required
// 7. The enum values are appropriate for batch job tracking and align with common status patterns
// 
// No changes required - the code follows .NET 8 best practices and is suitable for PostgreSQL persistence