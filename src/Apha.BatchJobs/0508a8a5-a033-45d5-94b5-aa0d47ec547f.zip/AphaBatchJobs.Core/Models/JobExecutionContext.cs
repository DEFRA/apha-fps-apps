namespace AphaBatchJobs.Core.Models;

using AphaBatchJobs.Core.Enums;

/// <summary>
/// Represents the execution context for a batch job.
/// Contains all necessary information to track and correlate a job execution instance.
/// </summary>
/// <param name="JobName">The unique name identifying the job being executed.</param>
/// <param name="CorrelationId">A unique identifier for correlating logs and tracking this specific execution.</param>
/// <param name="TriggerType">The type of trigger that initiated this job execution (Scheduled or Adhoc).</param>
/// <param name="StartedAt">The timestamp when the job execution started.</param>
public sealed record JobExecutionContext(
    string JobName,
    string CorrelationId,
    JobType TriggerType,
    DateTimeOffset StartedAt
)
{
    // Add validation to ensure required properties are not null or empty
    public JobExecutionContext(
        string JobName,
        string CorrelationId,
        JobType TriggerType,
        DateTimeOffset StartedAt) : this()
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(JobName, nameof(JobName));
        ArgumentException.ThrowIfNullOrWhiteSpace(CorrelationId, nameof(CorrelationId));
        
        this.JobName = JobName;
        this.CorrelationId = CorrelationId;
        this.TriggerType = TriggerType;
        this.StartedAt = StartedAt;
    }
}


**Key improvements made:**

1. **Sealed modifier**: Added `sealed` keyword to prevent inheritance, which is a best practice for records that represent data contracts and improves performance by allowing the compiler to make optimizations.

2. **Input validation**: Added explicit constructor with validation using `ArgumentException.ThrowIfNullOrWhiteSpace()` (available in .NET 8) to ensure `JobName` and `CorrelationId` are not null or empty, preventing invalid state.

3. **Defensive programming**: The validation ensures data integrity at the point of creation, which is especially important for tracking and correlation in distributed systems (AWS environments).

These changes maintain the existing functionality while making the code more robust and following .NET 8 best practices for immutable data models.