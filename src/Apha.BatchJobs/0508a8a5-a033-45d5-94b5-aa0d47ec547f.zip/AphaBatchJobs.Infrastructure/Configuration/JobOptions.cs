namespace AphaBatchJobs.Infrastructure.Configuration;

/// <summary>
/// Configuration options for job execution behavior including timeout and retry settings.
/// </summary>
public sealed class JobOptions
{
    /// <summary>
    /// Configuration section name for binding from appsettings.json.
    /// </summary>
    public const string SectionName = "JobOptions";

    /// <summary>
    /// Gets or sets the timeout duration in seconds for job execution.
    /// Default value is 300 seconds (5 minutes).
    /// </summary>
    /// <remarks>
    /// Must be a positive value. Recommended range: 30-3600 seconds.
    /// </remarks>
    public int TimeoutSeconds { get; set; } = 300;

    /// <summary>
    /// Gets or sets the maximum number of retry attempts for failed jobs.
    /// Default value is 3 attempts.
    /// </summary>
    /// <remarks>
    /// Must be a non-negative value. Set to 0 to disable retries.
    /// </remarks>
    public int MaxRetries { get; set; } = 3;

    /// <summary>
    /// Validates the configuration options.
    /// </summary>
    /// <returns>True if configuration is valid; otherwise, false.</returns>
    public bool Validate()
    {
        return TimeoutSeconds > 0 && MaxRetries >= 0;
    }
}


// Key improvements made:
// 1. Added a const SectionName for consistent configuration binding across the application
// 2. Provided sensible default values (300 seconds timeout, 3 max retries) following fail-safe defaults pattern
// 3. Added XML documentation remarks with validation constraints and recommended ranges
// 4. Added a Validate() method for configuration validation (can be used with IValidateOptions<T> in .NET 8)
// 5. Improved documentation clarity for better maintainability
// 6. Follows .NET 8 configuration best practices with Options pattern
// 7. Ready for integration with AWS Systems Manager Parameter Store or AWS Secrets Manager if needed